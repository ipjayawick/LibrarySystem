package lk.ijse.thogakade.dao;

import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import lk.ijse.thogakade.db.DBConnection;
import lk.ijse.thogakade.dto.CustomerDTO;
import lk.ijse.thogakade.dto.ItemDTO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class DataBaseAccessCode {

    public boolean saveCustomer(CustomerDTO dto) throws SQLException, ClassNotFoundException {
        Connection con = DBConnection.getInstance().getConnection();
        PreparedStatement stm =con.prepareStatement("INSERT INTO Customer VALUES(?,?,?,?)");
        stm.setObject(1, dto.getCode()); // Ctrl + D
        stm.setObject(2, dto.getName());
        stm.setObject(3, dto.getAddress());
        stm.setObject(4, dto.getSalary());
        return stm.executeUpdate()>0;
    }

    public boolean deleteCustomer(String code) throws SQLException, ClassNotFoundException {
        Connection connection = DBConnection.getInstance().getConnection();
        PreparedStatement statement= connection.prepareStatement("DELETE FROM Customer WHERE id=?");
        statement.setObject(1,code);
        return statement.executeUpdate()>0;
    }

    public CustomerDTO getCustomer(String code) throws SQLException, ClassNotFoundException {
        Connection con = DBConnection.getInstance().getConnection();
        PreparedStatement stm= con.prepareStatement("SELECT * FROM Customer WHERE id =?");
        stm.setObject(1,code);
        ResultSet set = stm.executeQuery();
        //---------------
        if (set.next()){
            return new CustomerDTO(set.getString(1),
                    set.getString(2),set.getString(3),
                    set.getDouble(4)
            );
        }
        return null;
    }

    public ArrayList<CustomerDTO> getAllCustomers() throws SQLException, ClassNotFoundException {
        Connection con = DBConnection.getInstance().getConnection();
        PreparedStatement stm= con.prepareStatement("SELECT * FROM Customer");
        ResultSet set = stm.executeQuery();
        ArrayList<CustomerDTO> customerList=new ArrayList();
        while (set.next()){
            customerList.add(new CustomerDTO(set.getString(1),
                    set.getString(2),set.getString(3),
                    set.getDouble(4)
            ));
        }
        return customerList;
    }

    public boolean saveItem(ItemDTO dto) throws SQLException, ClassNotFoundException {
        Connection con = DBConnection.getInstance().getConnection();
        PreparedStatement stm =con.prepareStatement("INSERT INTO Item VALUES(?,?,?,?)");
        stm.setObject(1, dto.getCode()); // Ctrl + D
        stm.setObject(2, dto.getDescription());
        stm.setObject(3, dto.getUnitPrice());
        stm.setObject(4, dto.getQtynHand());
        return stm.executeUpdate()>0;
    }

    public boolean deleteItem(String code) throws SQLException, ClassNotFoundException {
        System.out.println(code);
        Connection connection = DBConnection.getInstance().getConnection();
        PreparedStatement statement= connection.prepareStatement("DELETE FROM Item WHERE code=?");
        statement.setObject(1,code);
        return statement.executeUpdate()>0;
    }

    public ItemDTO getItem(String code) throws SQLException, ClassNotFoundException {
        Connection con = DBConnection.getInstance().getConnection();
        PreparedStatement stm= con.prepareStatement("SELECT * FROM Item WHERE code =?");
        stm.setObject(1,code);
        ResultSet set = stm.executeQuery();
        //---------------
        if (set.next()){
            return new ItemDTO(set.getString(1),
                    set.getString(2),set.getDouble(3),
                    set.getInt(4)
            );
        }
        return null;
    }

    public ArrayList<ItemDTO> getAllItems() throws SQLException, ClassNotFoundException {
        Connection con = DBConnection.getInstance().getConnection();
        PreparedStatement stm = con.prepareStatement("SELECT * FROM Item");
        ResultSet set = stm.executeQuery();
        //------------------
        ArrayList<ItemDTO> itemList=new ArrayList();
        while (set.next()){
            itemList.add(new ItemDTO(set.getString(1),
                    set.getString(2),set.getDouble(3),
                    set.getInt(4)
            ));
        }
        return itemList;
    }


}
