package lk.ijse.thogakade.controller;

import com.jfoenix.controls.JFXButton;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyEvent;
import lk.ijse.thogakade.dao.DataBaseAccessCode;
import lk.ijse.thogakade.db.DBConnection;
import lk.ijse.thogakade.dto.ItemDTO;
import lk.ijse.thogakade.view.tm.CustomerTM;
import lk.ijse.thogakade.view.tm.ItemTM;

import java.sql.*;
import java.util.ArrayList;
import java.util.Optional;

public class ItemFormController {
    public TextField txtCode;
    public TextField txtDescription;
    public TextField textSearch;
    public JFXButton btnSave;
    public TableView<ItemTM> tbl;
    public TableColumn colCode;
    public TableColumn colDescription;
    public TableColumn colUnitPrice;
    public TableColumn colQty;
    public TableColumn colOperate;
    public TextField txtUnitPrice;
    public TextField txtQTYOnHand;

    public void initialize() throws SQLException, ClassNotFoundException {
        colCode.setCellValueFactory(new PropertyValueFactory<>("code"));
        colDescription.setCellValueFactory(new PropertyValueFactory<>("description"));
        colUnitPrice.setCellValueFactory(new PropertyValueFactory<>("unitPrice"));
        colQty.setCellValueFactory(new PropertyValueFactory<>("qtyOnHand"));
        colOperate.setCellValueFactory(new PropertyValueFactory<>("btn"));
        loadAllItems(); // Alt + Enter
    }

    private void loadAllItems() throws ClassNotFoundException, SQLException {
        ArrayList<ItemDTO> itemList= new DataBaseAccessCode().getAllItems();
        ObservableList<ItemTM> obList = FXCollections.observableArrayList();
        for (ItemDTO item:itemList) {
            JFXButton btn = new JFXButton("Delete");
            ItemTM tm = new ItemTM(item.getCode(),
                    item.getDescription(),
                    item.getUnitPrice(),
                    item.getQtynHand(),
                    btn);
            obList.add(tm);

            btn.setOnAction(e -> {
                ButtonType ok = new ButtonType("OK",
                        ButtonBar.ButtonData.OK_DONE);
                ButtonType no = new ButtonType("NO",
                        ButtonBar.ButtonData.CANCEL_CLOSE);
                Alert alert = new Alert(
                        Alert.AlertType.CONFIRMATION,
                        "Are You Sure whether You Want to Delete This Item?",
                        ok, no);
                Optional<ButtonType> result = alert.showAndWait();
                if (result.orElse(no) == ok) {
                  // delete the item

                    try {
                        boolean isDeleted = new DataBaseAccessCode().deleteItem(tm.getCode());
                        if (isDeleted){
                            new Alert(Alert.AlertType.CONFIRMATION,"Deleted !",
                                    ButtonType.OK).show();
                        }else{
                            new Alert(Alert.AlertType.WARNING,"Try Again !",
                                    ButtonType.OK).show();
                        }
                    } catch (ClassNotFoundException e1) {
                        e1.printStackTrace();
                    } catch (SQLException e1) {
                        e1.printStackTrace();
                    }


                }

            });

            tbl.setItems(obList);

        }
    }

    public void filterOnAction(ActionEvent actionEvent) throws ClassNotFoundException, SQLException {
       ItemDTO item= new DataBaseAccessCode().getItem(txtCode.getText());
        if (item!=null){
            txtDescription.setText(item.getDescription());
            txtUnitPrice.setText(String.valueOf(item.getUnitPrice())); // Standard Way **********
            txtQTYOnHand.setText(item.getQtynHand()+"");
        }else{
            new Alert(Alert.AlertType.WARNING,"Item Not Found!",
                    ButtonType.OK).show();
        }
    }

    public void searchOnAction(KeyEvent keyEvent) {
    }

    public void saveAndUpdateOnAction(ActionEvent actionEvent) throws ClassNotFoundException, SQLException {

        if (btnSave.getText().equalsIgnoreCase("Save")) {
            // save
            ItemDTO item= new ItemDTO(
                    txtCode.getText(),
                    txtDescription.getText(),
                    Double.parseDouble(txtUnitPrice.getText()),
                   Integer.parseInt(txtQTYOnHand.getText())
            );
            boolean isSaved = new DataBaseAccessCode().saveItem(item);
            System.out.println(isSaved);
        } else {
            // update
        }

    }

    public void newOnAction(ActionEvent actionEvent) {
    }
}
