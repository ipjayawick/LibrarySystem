package lk.ijse.thogakade.controller;

import com.jfoenix.controls.JFXButton;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyEvent;
import lk.ijse.thogakade.dao.DataBaseAccessCode;
import lk.ijse.thogakade.db.DBConnection;
import lk.ijse.thogakade.dto.CustomerDTO;
import lk.ijse.thogakade.view.tm.CustomerTM;

import java.sql.*;
import java.util.ArrayList;
import java.util.Optional;

public class CustomerFormController {
    public TextField txtId;
    public TextField txtName;
    public TextField txtAddress;
    public TextField txtSalary;
    public TextField txtSearch;
    public JFXButton btnSave;
    public TableView<CustomerTM> tbl;
    public TableColumn colId;
    public TableColumn colName;
    public TableColumn colAddress;
    public TableColumn colSalary;
    public TableColumn colOperate;

    public void initialize() throws SQLException, ClassNotFoundException {
        colId.setCellValueFactory(new PropertyValueFactory<>("code"));
        colName.setCellValueFactory(new PropertyValueFactory<>("name"));
        colAddress.setCellValueFactory(new PropertyValueFactory<>("address"));
        colSalary.setCellValueFactory(new PropertyValueFactory<>("salary"));
        colOperate.setCellValueFactory(new PropertyValueFactory<>("btn"));
        loadAllCustomers(); // Alt + Enter
    }

    private void loadAllCustomers() throws ClassNotFoundException, SQLException {

        ArrayList<CustomerDTO> allCustomers = new DataBaseAccessCode().getAllCustomers();
        ObservableList<CustomerTM> obList= FXCollections.observableArrayList();
        for (CustomerDTO dto:allCustomers){
            JFXButton btn= new JFXButton("Delete");
            CustomerTM tm=new CustomerTM(
                    dto.getCode(),
                    dto.getName(),
                    dto.getAddress(),
                    dto.getSalary(),
                    btn);
            obList.add(tm);

           btn.setOnAction(e->{
                 ButtonType ok= new ButtonType("OK",
                         ButtonBar.ButtonData.OK_DONE);
                 ButtonType no= new ButtonType("NO",
                         ButtonBar.ButtonData.CANCEL_CLOSE);
                 Alert alert= new Alert(
                         Alert.AlertType.CONFIRMATION,
                         "Are You Sure whether You Want to Delete This Customer?",
                         ok,no);
               Optional<ButtonType> result = alert.showAndWait();
               if (result.orElse(no)==ok){
                   try {
                       boolean isDeleted = new DataBaseAccessCode().
                               deleteCustomer(tm.getCode());
                       if (isDeleted){
                           new Alert(Alert.AlertType.CONFIRMATION,"Deleted !",
                                   ButtonType.OK).show();
                       }else{
                           new Alert(Alert.AlertType.WARNING,"Try Again !",
                                   ButtonType.OK).show();
                       }
                   } catch (ClassNotFoundException e1) {
                       e1.printStackTrace();
                   } catch (SQLException e1) {
                       e1.printStackTrace();
                   }
               }else{

               }

           });

        }

        tbl.setItems(obList);

    }


    public void searchOnAction(KeyEvent keyEvent) {
    }

    public void filterOnAction(ActionEvent actionEvent) throws ClassNotFoundException, SQLException {

        CustomerDTO dto=new DataBaseAccessCode().getCustomer(txtId.getText());
        if (dto!=null){
            txtName.setText(dto.getName());
            txtAddress.setText(dto.getAddress());
            txtSalary.setText(dto.getSalary()+"");
        }else{
            new Alert(Alert.AlertType.WARNING,"Customer Not Found!",
                    ButtonType.OK).show();
        }
    }

    public void saveUpdateOnAction(ActionEvent actionEvent) throws ClassNotFoundException, SQLException {

        if (btnSave.getText().equalsIgnoreCase("Save")) {
            // save
            CustomerDTO dto= new CustomerDTO(
                    txtId.getText(),
                    txtName.getText(),
                    txtAddress.getText(),
                    Double.parseDouble(txtSalary.getText())
            );
            boolean isSaved = new DataBaseAccessCode().
                    saveCustomer(dto);
            System.out.println(isSaved);
        } else {
            // update
        }

    }

    public void newOnAction(ActionEvent actionEvent) {
    }
}
